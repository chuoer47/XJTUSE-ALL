package BST;

public class Verify {
    public static void main(String[] args) {

    }
}
